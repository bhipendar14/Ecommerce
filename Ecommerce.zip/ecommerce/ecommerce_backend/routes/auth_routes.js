const express = require("express");
let bcrypt = require("bcrypt");
var jwt = require("jsonwebtoken");

const router = express.Router();

// const authController = require("../controllers/authController");
const User = require("../models/user_model");
const authCheck = require("../middleware/auth_middleware");

const creteToken = (_id) => {
  return jwt.sign({ _id }, process.env.TOKEN_KEY, {
    expiresIn: "1d",
  });
};

router.post("/signup", async (req, res) => {
  const { name, email, password, profilePic, role } = req.body;
  //   console.log("Signup route ", name, email, password);
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);

  User.findOne({ email: email })
    .then(async (user) => {
      if (user) {
        res.status(400).send({
          message: "User already exists with this email",
        });
      } else {
        try {
          const newUser = await User.create({
            name,
            email,
            password: hashedPassword,
            profilePic,
            role,
          });

          let token = creteToken(newUser._id);

          res.send({
            token: token,
            message: "User Created",
          });
        } catch (error) {
          res.status(401).send({
            error,
          });
        }
      }
    })
    .catch((err) => {
      res.send("Backend error");
    });
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email: email });
  if (!user) {
    return res.status(400).send({
      message: "User not found with this email",
    });
  }

  const isCorrectPass = await bcrypt.compare(password, user.password);
  console.log(isCorrectPass);
  if (!isCorrectPass) {
    return res.status(404).send({ message: "Unauthorized" });
  }

  const token = creteToken(user._id);

  res.send({
    token: token,
    role: user.role,
    message: "User login successful",
  });
});

//User Get
router.get("/auth/me", authCheck, async (req, res) => {
  const userID = req.user._id;
  const user = await User.findById(userID);

  res.send({
    data: user,
    message: "User Data",
  });
});

module.exports = router;
