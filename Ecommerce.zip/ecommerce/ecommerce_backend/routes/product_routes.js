const express = require("express");

const Proudct = require("../models/product_model");
const authCheck = require("../middleware/auth_middleware");
const router = express.Router();
//Create Produc
router.post("/product", authCheck, async (req, res) => {
  const {
    title,
    description,
    price,
    discountPercentage,
    rating,
    stock,
    brand,
    category,
    thumbnail,
  } = req.body;
  //   console.log("Error,", req.body);
  try {
    const product = await Proudct.create({
      title,
      description,
      price,
      discountPercentage,
      rating,
      stock,
      brand,
      category,
      thumbnail,
    });

    res.send({
      message: "Product Created",
      data: product,
    });
  } catch (error) {
    res.send({
      message: "Server error",
    });
  }
});

//Get Products
router.get("/products", authCheck, async (req, res) => {
  const products = await Proudct.find();

  res.send({
    message: "Products Fetched",
    data: products,
  });
});

//Get Product by ID
router.get("/product/:id", authCheck, async (req, res) => {
  const product = await Proudct.findById(req.params.id);

  res.send({
    message: "Product Fetched",
    data: product,
  });
});

//Update Product
router.put("/product/:id", authCheck, async (req, res) => {
  const {
    title,
    description,
    price,
    discountPercentage,
    rating,
    stock,
    brand,
    category,
    thumbnail,
  } = req.body;

  try {
    const product = await Proudct.findByIdAndUpdate(
      req.params.id,
      {
        title,
        description,
        price,
        discountPercentage,
        rating,
        stock,
        brand,
        category,
        thumbnail,
      },
      { new: true }
    );

    res.send({
      message: "Product Updated",
      data: product,
    });
  } catch (error) {
    res.send({
      message: "Server error",
    });
  }
});

//Delete Product
router.delete("/product/:id", authCheck, async (req, res) => {
  try {
    const product = await Proudct.findByIdAndDelete(req.params.id);

    res.send({
      message: "Product Deleted",
      data: product,
    });
  } catch (error) {
    res.send({
      message: "Server error",
    });
  }
});

module.exports = router;
