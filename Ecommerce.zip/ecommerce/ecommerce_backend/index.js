const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
require("dotenv").config();

const userRoutes = require("./routes/auth_routes");
const productRoutes = require("./routes/product_routes");

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(userRoutes);
app.use(productRoutes);

mongoose
  .connect(process.env.MONGO_URL)
  .then((res) => {
    app.listen(process.env.PORT);
    console.log(`DB connected and listening on port ${process.env.PORT}`);
  })
  .catch((err) => {
    console.log(err);
  });
