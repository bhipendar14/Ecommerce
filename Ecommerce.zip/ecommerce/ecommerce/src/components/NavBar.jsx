import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "../assets/Navbar.css";

export default function NavBar() {
  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");
  const navigate = useNavigate();
  // console.log("token", token);

  const onLogout = (e) => {
    e.preventDefault();
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/login");
  };
  return (
    <nav className="navbar">
      <Link to="/">
        {" "}
        <div className="navbar-brand">E-Store</div>
      </Link>
      <ul className="navbar-nav">
        {/* <li className="nav-item">
          <a href="#" className="nav-link">
            Categories
          </a>
        </li> */}
        {token && (
          <li className="nav-item">
            <Link to="/user" className="nav-link">
              Profile
            </Link>
          </li>
        )}
        {role === "admin" ? (
          <li className="nav-item">
            <Link to="/createProduct" className="nav-link">
              Create Product
            </Link>
          </li>
        ) : null}
        {/* {role === "admin" ? (
          <li className="nav-item">
            <Link to="/manageProduct" className="nav-link">
              Manage Product
            </Link>
          </li>
        ) : null} */}
        {token == null ? (
          <li className="nav-item">
            <Link to="/login" className="nav-link">
              Login
            </Link>
          </li>
        ) : (
          <li className="nav-item">
            <li onClick={(e) => onLogout(e)} className="nav-link">
              Logout
            </li>
          </li>
        )}

        {token == null ? (
          <li className="nav-item">
            <Link to="/signup" className="nav-link">
              Signup
            </Link>
          </li>
        ) : null}
      </ul>
    </nav>
  );
}
