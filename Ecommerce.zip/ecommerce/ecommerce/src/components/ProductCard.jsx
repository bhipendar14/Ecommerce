import React from "react";
import "./ProductCard.css";
import { useNavigate } from "react-router-dom";

export default function ProductCard({ product }) {
  const priceString = String(product.price);
  const priceWithoutDollarSign = priceString.slice(0);
  const token = localStorage.getItem("token");
  console.log(priceWithoutDollarSign);
  const navigate = useNavigate();
  const productId = product._id;
  return (
    <div
      onClick={() => navigate(`/productDetail/${productId}`)}
      className="product-card"
    >
      <div className="product-image">
        <img src={product.thumbnail} alt={product.title} />
      </div>
      <div className="product-info">
        <h3>{product.title}</h3>
        <p className="price">Price: Rs.{priceWithoutDollarSign}00</p>

        <div className="rating">
          Rating: {product.rating}{" "}
          <span role="img" aria-label="star">
            ⭐️
          </span>
        </div>

        {/* Check if the user is logged in or not  */}
        {token && <button className="btn">Add to Cart</button>}
        <br />
        <br />
        {/* Check if it is admin and then redirect to the manage product page */}
        {token && localStorage.getItem("role") === "admin" && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/manageProduct/${productId}`);
            }}
            className="btn-edit"
          >
            Edit Product
          </button>
        )}
        {/* Check if it is admin and then redirect to the manage product page */}
        {token && localStorage.getItem("role") === "admin" && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              // navigate(`/manageProduct/${productId}`);
              fetch(`http://localhost:3000/product/${productId}`, {
                method: "DELETE",
                headers: {
                  Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
              })
                .then((res) => res.json())
                .then((res) => {
                  console.log(res);
                  navigate("/");
                });
            }}
            className="btn-delete"
          >
            Delete
          </button>
        )}
      </div>
    </div>
  );
}
