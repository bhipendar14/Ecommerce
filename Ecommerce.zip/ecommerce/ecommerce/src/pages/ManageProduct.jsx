import React, { useEffect, useState } from "react";

import "../assets/Signup.css";
import NavBar from "../components/NavBar";
import { useNavigate, useParams } from "react-router-dom";

const ManageProduct = () => {
  const navigate = useNavigate();
  const params = useParams();
  const { id } = params;

  const [loading, setLoading] = useState(false);

  const [product, setProduct] = useState({
    title: "",
    description: "",
    price: "",
    discountPercentage: "",
    rating: "",
    stock: "",
    brand: "",
    category: "",
    thumbnail: "",
  });
  const [error, setError] = useState("");

  useEffect(() => {
    setLoading(true);
    fetch(`http://localhost:3000/product/${id}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        setProduct(data.data);
        setLoading(false);
      });
  }, [id]);

  const onEditButtonClick = (e) => {
    e.preventDefault();
    try {
      fetch(`http://localhost:3000/product/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify(product),
      })
        .then((res) => res.json())
        .then((res) => {
          console.log(res);

          navigate("/");
        });
    } catch (error) {
      console.log("Signup failed", error);
      setError("Signup failed");
    }
  };

  return (
    <div>
      <NavBar />
      <div className="product-container">
        <div className="signup-form">
          <h2>Edit Product</h2>
          <form>
            <div className="input-group">
              <label htmlFor="title">Title:</label>
              <input
                type="text"
                onChange={(e) => {
                  setProduct({ ...product, title: e.target.value });
                }}
                value={product.title}
                id="title"
                name="title"
              />
            </div>
            <div className="input-group">
              <label htmlFor="description">Description:</label>
              <input
                type="text"
                onChange={(e) => {
                  setProduct({ ...product, description: e.target.value });
                }}
                value={product.description}
                id="description"
                name="description"
              />
            </div>
            <div className="input-group">
              <label htmlFor="price">Price:</label>
              <input
                type="text"
                onChange={(e) => {
                  setProduct({ ...product, price: e.target.value });
                }}
                value={product.price}
                id="price"
                name="price"
              />
            </div>
            <div className="input-group">
              <label htmlFor="discountPercentage">Discount Percentage:</label>
              <input
                type="text"
                onChange={(e) => {
                  setProduct({
                    ...product,
                    discountPercentage: e.target.value,
                  });
                }}
                value={product.discountPercentage}
                id="discountPercentage"
                name="discountPercentage"
              />
            </div>
            <div className="input-group">
              <label htmlFor="rating">Rating:</label>
              <input
                type="text"
                onChange={(e) => {
                  setProduct({ ...product, rating: e.target.value });
                }}
                value={product.rating}
                id="rating"
                name="rating"
              />
            </div>
            <div className="input-group">
              <label htmlFor="stock">Stock:</label>
              <input
                type="text"
                onChange={(e) => {
                  setProduct({ ...product, stock: e.target.value });
                }}
                value={product.stock}
                id="stock"
                name="stock"
              />
            </div>
            <div className="input-group">
              <label htmlFor="brand">Brand:</label>
              <input
                type="text"
                onChange={(e) => {
                  setProduct({ ...product, brand: e.target.value });
                }}
                value={product.brand}
                id="brand"
                name="brand"
              />
            </div>
            <div className="input-group">
              <label htmlFor="category">Category:</label>
              <input
                type="text"
                onChange={(e) => {
                  setProduct({ ...product, category: e.target.value });
                }}
                value={product.category}
                id="category"
                name="category"
              />
            </div>
            <div className="input-group">
              <label htmlFor="thumbnail">Thumbnail:</label>
              <input
                type="text"
                onChange={(e) => {
                  setProduct({ ...product, thumbnail: e.target.value });
                }}
                value={product.thumbnail}
                id="thumbnail"
                name="thumbnail"
              />
            </div>

            <p className="error">{error}</p>

            <button
              onClick={(e) => onEditButtonClick(e)}
              type="submit"
              className="btn-signup"
            >
              Edit Product
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ManageProduct;
