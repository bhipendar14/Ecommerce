import React, { useEffect, useState } from "react";
import "../assets/Login.css";
import NavBar from "../components/NavBar";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const onLoginButtonClick = (e) => {
    e.preventDefault();
    try {
      console.log("Login button clicked");
      fetch("http://localhost:3000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: email,
          password: password,
        }),
      })
        .then((res) => res.json())
        .then((res) => {
          console.log(res);
          // console.log("Login successful", res.token);

          if (!res.token) {
            setError("Login failed");
            throw new Error("Login failed");
          }
          localStorage.setItem("role", res.role);
          localStorage.setItem("token", res.token);
          navigate("/");
        });
    } catch (error) {
      console.log("Login failed", error);
      setError("Login failed");
    }
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/");
    }
  }, [navigate]);

  return (
    <div>
      <NavBar />
      <div className="login-container">
        <div className="login-form">
          <h2>Login</h2>
          <p className="error">{error}</p>
          <form>
            <div className="input-group">
              <label htmlFor="email">Email:</label>

              <input
                type="email"
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
                id="email"
                name="email"
              />
            </div>
            <div className="input-group">
              <label htmlFor="password">Password:</label>
              <input
                type="password"
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
                id="password"
                name="password"
              />
            </div>
            <button
              type="submit"
              onClick={(e) => onLoginButtonClick(e)}
              className="btn-login"
            >
              Login
            </button>
          </form>
          <p className="register-link">
            Don't have an account? <a href="/signup">Register</a>
          </p>
        </div>
      </div>
    </div>
  );
}
