import React, { useState, useEffect } from "react";
import "../App.css";
import ProductCard from "../components/ProductCard";
import { Link } from "react-router-dom";
import NavBar from "../components/NavBar";

// Define Homepage component
const Homepage = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/products", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    })
      .then((response) => response.json())
      .then((data) => setProducts(data.data))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);
  // console.log("Product ID: ", products[0]._id);

  return (
    <>
      <NavBar />
      <div className="homepage">
        <h1>Welcome to Electronics Store</h1>
        <div className="product-list">
          {products.map((product) => {
            const productId = product._id;
            // <Link to={`/productDetail/1`} className="product-card">
            return <ProductCard key={productId} product={product} />;
            // </Link>
          })}
        </div>
      </div>
    </>
  );
};

export default Homepage;
