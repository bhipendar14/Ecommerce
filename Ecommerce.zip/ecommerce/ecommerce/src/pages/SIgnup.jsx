import React, { useEffect, useState } from "react";

import "../assets/Signup.css";
import NavBar from "../components/NavBar";
import { useNavigate } from "react-router-dom";

const Signup = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const onSignupButtonClick = (e) => {
    e.preventDefault();
    try {
      console.log("Login button clicked");
      fetch("http://localhost:3000/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name,
          email: email,
          password: password,
        }),
      })
        .then((res) => res.json())
        .then((res) => {
          console.log(res);
          console.log("Signup successful", res.token);
          if (!res.token) {
            setError("Signup failed");
            throw new Error("Signup failed");
          }
          localStorage.setItem("token", res.token);
          navigate("/");
        });
    } catch (error) {
      console.log("Signup failed", error);
      setError("Signup failed");
    }
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/");
    }
  }, [navigate]);
  return (
    <div>
      <NavBar />
      <div className="signup-container">
        <div className="signup-form">
          <h2>Signup</h2>
          <form>
            <div className="input-group">
              <label htmlFor="name">Name:</label>
              <input
                type="text"
                onChange={(e) => {
                  setName(e.target.value);
                }}
                id="name"
                name="name"
              />
            </div>
            <div className="input-group">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
                id="email"
                name="email"
              />
            </div>
            <div className="input-group">
              <label htmlFor="password">Password:</label>
              <input
                type="password"
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
                id="password"
                name="password"
              />
            </div>
            <button
              onClick={(e) => onSignupButtonClick(e)}
              type="submit"
              className="btn-signup"
            >
              Signup
            </button>
          </form>
          <p className="login-link">
            Already have an account? <a href="/login">Login</a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Signup;
