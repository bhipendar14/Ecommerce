import React, { useEffect, useState } from "react";

import "../assets/Signup.css";
import NavBar from "../components/NavBar";
import { useNavigate } from "react-router-dom";

const CreateProduct = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [discountPercentage, setDiscountPercentage] = useState("");
  const [rating, setRating] = useState("");
  const [stock, setStock] = useState("");
  const [brand, setBrand] = useState("");
  const [category, setCategory] = useState("");
  const [thumbnail, setThumbnail] = useState("");

  const [error, setError] = useState("");

  const onAddButtonClick = (e) => {
    e.preventDefault();
    try {
      fetch("http://localhost:3000/product", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify({
          title: title,
          description: description,
          price: price,
          discountPercentage: discountPercentage,
          rating: rating,
          stock: stock,
          brand: brand,
          category: category,
          thumbnail: thumbnail,
        }),
      })
        .then((res) => res.json())
        .then((res) => {
          console.log(res);

          navigate("/");
        });
    } catch (error) {
      console.log("Signup failed", error);
      setError("Signup failed");
    }
  };

  return (
    <div>
      <NavBar />
      <div className="product-container">
        <div className="signup-form">
          <h2>Add New Product</h2>
          <form>
            <div className="input-group">
              <label htmlFor="title">Title:</label>
              <input
                type="text"
                onChange={(e) => {
                  setTitle(e.target.value);
                }}
                id="title"
                name="title"
              />
            </div>
            <div className="input-group">
              <label htmlFor="description">Description:</label>
              <input
                type="text"
                onChange={(e) => {
                  setDescription(e.target.value);
                }}
                id="description"
                name="description"
              />
            </div>
            <div className="input-group">
              <label htmlFor="price">Price:</label>
              <input
                type="number"
                onChange={(e) => {
                  setPrice(e.target.value);
                }}
                id="price"
                name="price"
              />
            </div>
            <div className="input-group">
              <label htmlFor="discountPercentage">Discount Percentage:</label>
              <input
                type="number"
                onChange={(e) => {
                  setDiscountPercentage(e.target.value);
                }}
                id="discountPercentage"
                name="discountPercentage"
              />
            </div>
            <div className="input-group">
              <label htmlFor="rating">Rating:</label>
              <input
                type="number"
                onChange={(e) => {
                  setRating(e.target.value);
                }}
                id="rating"
                name="rating"
              />
            </div>
            <div className="input-group">
              <label htmlFor="stock">Stock:</label>
              <input
                type="number"
                onChange={(e) => {
                  setStock(e.target.value);
                }}
                id="stock"
                name="stock"
              />
            </div>
            <div className="input-group">
              <label htmlFor="brand">Brand:</label>
              <input
                type="text"
                onChange={(e) => {
                  setBrand(e.target.value);
                }}
                id="brand"
                name="brand"
              />
            </div>
            <div className="input-group">
              <label htmlFor="category">Category:</label>
              <input
                type="text"
                onChange={(e) => {
                  setCategory(e.target.value);
                }}
                id="category"
                name="category"
              />
            </div>
            <div className="input-group">
              <label htmlFor="thumbnail">Thumbnail:</label>
              <input
                type="text"
                onChange={(e) => {
                  setThumbnail(e.target.value);
                }}
                id="thumbnail"
                name="thumbnail"
              />
            </div>
            <p className="error">{error}</p>

            <button
              onClick={(e) => onAddButtonClick(e)}
              type="submit"
              className="btn-signup"
            >
              Add Product
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateProduct;
