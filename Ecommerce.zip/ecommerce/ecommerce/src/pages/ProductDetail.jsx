// ProductDetail.js

import React, { useEffect, useState } from "react";
import "../assets/ProductDetail.css";
import NavBar from "../components/NavBar";
import { useParams } from "react-router-dom";

const Dialog = ({ isOpen, onClose, children }) => {
  return (
    <>
      {isOpen && (
        <div className="dialog-overlay">
          <div className="dialog-content">
            <button className="close-btn" onClick={onClose}>
              Close
            </button>
            {children}
          </div>
        </div>
      )}
    </>
  );
};

const ProductDetail = () => {
  const [product, setProduct] = useState({});
  const [loading, setLoading] = useState(true);
  const params = useParams();
  const { id } = params;
  // console.log(params, "Params");

  useEffect(() => {
    setLoading(true);
    fetch(`http://localhost:3000/product/${id}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    })
      .then((res) => res.json())
      .then((data) => setProduct(data.data));

    setLoading(false);
  }, []);

  const {
    title,
    description,
    price,
    discountPercentage,
    rating,
    stock,
    brand,
    category,
    thumbnail,
  } = product;

  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleDialogToggle = () => {
    setIsDialogOpen(!isDialogOpen);
  };
  console.log(isDialogOpen);
  return (
    <>
      <NavBar />
      <div className="product-detail-single">
        <div className="thumbnail-container">
          <img src={thumbnail} alt={title} className="thumbnail" />
        </div>
        <div className="product-info-single">
          <h1>{title}</h1>
          <p className="description">{description}</p>
          <p className="price-single">Price: ${price}</p>
          <p className="discount">Discount: {discountPercentage}%</p>
          <Dialog isOpen={isDialogOpen} onClose={handleDialogToggle}>
            <h2>Order placed successfully.</h2>
          </Dialog>
          <button onClick={handleDialogToggle} className="button">
            Buy Now
          </button>
          <p className="rating-single">Rating: {rating}</p>
          <p className="stock">Stock: {stock}</p>
          <p className="brand">Brand: {brand}</p>
          <p className="category">Category: {category}</p>
        </div>
      </div>
    </>
  );
};

export default ProductDetail;
