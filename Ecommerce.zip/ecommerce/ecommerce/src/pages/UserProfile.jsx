// UserProfile.js

import React, { useEffect, useState } from "react";
import "../assets/UserProfile.css";
import NavBar from "../components/NavBar";

const UserProfile = () => {
  const [user, setUser] = useState({});

  useEffect(() => {
    fetch("http://localhost:3000/auth/me", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    })
      .then((response) => response.json())
      .then((data) => setUser(data.data))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  console.log(user);
  const { _id, email, name, profilePic } = user;

  return (
    <>
      <NavBar />
      <div className="user-profile">
        <div className="user-info">
          <img
            src={"https://picsum.photos/200/300"}
            alt={`Profile of ${email}`}
            className="user-avatar"
          />
          {/* <h1>{username}</h1> */}
          <p>Name: {name}</p>
          <p>Email: {email}</p>
        </div>
      </div>
    </>
  );
};

export default UserProfile;
