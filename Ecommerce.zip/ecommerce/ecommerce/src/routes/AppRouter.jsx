import * as ReactDOM from "react-dom";
import { createBrowserRouter, RouterProvider } from "react-router-dom";

import Homepage from "../pages/Homepage";
import Login from "../pages/Login";
import Signup from "../pages/SIgnup";
import ProductDetail from "../pages/ProductDetail";
import UserProfile from "../pages/UserProfile";
import CreateProduct from "../pages/CreateProduct";
import ManageProduct from "../pages/ManageProduct";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Homepage />,

    children: [],
  },
  {
    path: "/login",
    element: <Login />,

    children: [],
  },
  {
    path: "/signup",
    element: <Signup />,

    children: [],
  },
  {
    path: "/productDetail/:id",
    element: <ProductDetail />,

    children: [],
  },
  {
    path: "/user",
    element: <UserProfile />,

    children: [],
  },
  {
    path: "/createProduct",
    element: <CreateProduct />,

    children: [],
  },
  {
    path: "/manageProduct/:id",
    element: <ManageProduct />,

    children: [],
  },
]);

export default function AppRouter() {
  return <RouterProvider router={router} />;
}

// ReactDOM.createRoot(document.getElementById("root")).render(
//   <RouterProvider router={router} />
// );
